Hi All, these are all the (self-created) art assets I created and used in my minigame "PoE Simulator". 
.mat files are materials as used in unity
.max files are animated models from 3ds max

I am hereby releasing them (all art assets in this folder) into the public domain for anyone to use, perpetually, free of charge, for any commercial and non-commercial purpose as per Creative Commons Legal Code CC0 1.0 Universal.

Further information can be found at https://creativecommons.org/publicdomain/zero/1.0/legalcode.txt